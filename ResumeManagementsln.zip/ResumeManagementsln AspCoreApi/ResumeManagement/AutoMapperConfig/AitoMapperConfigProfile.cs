﻿using AutoMapper;
using ResumeManagement.DTOs;
using ResumeManagement.Entities;

namespace ResumeManagement.AutoMapperConfig
{
    public class AitoMapperConfigProfile:Profile
    {
        public AitoMapperConfigProfile()
        {
            CreateMap<CompanyCreateDto, Company>();
            CreateMap<Company, CompanyGetDto>();

            CreateMap<CandidateCreateDto, Candidate>();
            CreateMap<Candidate, CandidateGetDto>().ForMember(dest => dest.Title, opt => opt.MapFrom(src => src.Job.Title));

            CreateMap<JobCreateDto, Job>();
            CreateMap<Job, JobGetDto>().ForMember(dest => dest.CompanyName, opt => opt.MapFrom(src => src.Company.CompanyName));

            
        }
    }
}
