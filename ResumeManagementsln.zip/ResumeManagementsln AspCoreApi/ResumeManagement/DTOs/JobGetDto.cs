﻿using ResumeManagement.Enums;

namespace ResumeManagement.DTOs
{
    public class JobGetDto
    {
        public long Id { get; set; }
        public string Title { get; set; }
        public JobLabel LavelofJob { get; set; }
        public long CompanyId { get; set; }
        public string CompanyName { get; set;}
        public DateTime CreateDate { get; set; } = DateTime.Now;
    }
}
