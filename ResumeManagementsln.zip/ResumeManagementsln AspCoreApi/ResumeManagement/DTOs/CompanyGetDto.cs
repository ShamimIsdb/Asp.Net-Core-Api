﻿using ResumeManagement.Enums;

namespace ResumeManagement.DTOs
{
    public class CompanyGetDto
    {
        public long Id { get; set; }
        public string CompanyName { get; set; }
        public CompanySize Size { get; set; }
        public DateTime CreateDate { get; set; } = DateTime.Now;
    }
}
