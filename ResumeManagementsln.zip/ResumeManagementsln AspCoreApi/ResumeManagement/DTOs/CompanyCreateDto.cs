﻿using ResumeManagement.Enums;

namespace ResumeManagement.DTOs
{
    public class CompanyCreateDto
    {
        public string CompanyName { get; set; }
        public CompanySize Size { get; set; }
    }
}
