﻿using ResumeManagement.Enums;

namespace ResumeManagement.DTOs
{
    public class JobCreateDto
    {
        public string Title { get; set; }
        public JobLabel LavelofJob { get; set; }
        public long CompanyId { get; set; }
    }
}
