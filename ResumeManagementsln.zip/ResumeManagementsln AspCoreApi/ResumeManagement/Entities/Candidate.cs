﻿namespace ResumeManagement.Entities
{
    public class Candidate:BaseEntity
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string MobileNo { get; set; }
        public string ImageName { get; set; }
        public string ImageUrl { get; set; }
        public long JobId { get; set; }
        public virtual Job Job { get; set; }
    }
}
