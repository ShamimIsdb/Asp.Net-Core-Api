﻿using ResumeManagement.Enums;

namespace ResumeManagement.Entities
{
    public class Job:BaseEntity
    {
        public string Title { get; set; }
        public JobLabel LavelofJob { get; set; }
        public long CompanyId { get; set; }
        public virtual Company Company  { get; set;}
        public ICollection<Candidate> Candidates { get; set; }  
    }
}
