﻿using ResumeManagement.Enums;

namespace ResumeManagement.Entities
{
    public class Company:BaseEntity
    {
        public string CompanyName { get; set; }
        public CompanySize Size { get; set;}
        public ICollection<Job> Jobs { get; set; }  
    }
}
