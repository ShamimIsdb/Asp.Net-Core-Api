﻿namespace ResumeManagement.Enums
{
    public enum CompanySize
    {
        Small,Medium,Large    
    }
    public enum JobLabel
    {
        Intern,Developer,Ssenior_developer,TeamLead,CTO
    }
}
